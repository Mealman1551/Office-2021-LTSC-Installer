Hello, This is the unofficial setup for Microsoft Office LTSC 2021.

1. you need to run "LTSC Installer", this file will actualy behind the scenes run: setup.exe /configure Configuration.xml
ps.
I choosed to use a exe instead of a batch file because I can sign a .exe file

2. Wait for the installer to run, this can be inside of the system tray

3. Enjoy your legally pre-activated copy with gvlk license

The cmd window will display a message in Dutch because it was originally made for a Dutch friend of mine who needed Office.